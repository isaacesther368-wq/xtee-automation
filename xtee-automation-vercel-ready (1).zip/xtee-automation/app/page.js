
export default function AutomationLandingPage() {
  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center">
      <div className="text-center px-6">
        <h1 className="text-6xl font-bold mb-6">Xtee Automations</h1>
        <p className="text-xl text-gray-300 mb-10">
          Premium AI Automation & Website Solutions
        </p>

        <a
          href="https://wa.me/2348133018271"
          target="_blank"
          className="px-8 py-4 rounded-2xl bg-green-500 hover:bg-green-600 transition"
        >
          Chat on WhatsApp
        </a>
      </div>
    </div>
  )
}
