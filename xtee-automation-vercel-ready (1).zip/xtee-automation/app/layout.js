
import './globals.css'

export const metadata = {
  title: 'Xtee Automations',
  description: 'Premium AI Automation Agency',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
