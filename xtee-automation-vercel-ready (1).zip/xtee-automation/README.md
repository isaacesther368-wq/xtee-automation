
# Xtee Automations

## One-Click Vercel Deployment

1. Extract the ZIP
2. Upload to GitHub
3. Import into Vercel
4. Click Deploy

Local Development:

npm install
npm run dev
